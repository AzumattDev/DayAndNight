| `Version` | `Update Notes`                                                            |
|-----------|---------------------------------------------------------------------------|
| 1.0.2     | - Update for 0.5.12                                                       |
| 1.0.2     | - Update the configuration explanations<br/> - Update the mod description |
| 1.0.1     | - Bug fix to the hotkey, I let automation fuck me up here lol             |
| 1.0.0     | - Initial Release                                                         |